make MALI_PLATFORM=scx15 BUILD=no KDIR=../common $1
