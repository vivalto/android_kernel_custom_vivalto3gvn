const char *__malidrv_build_info(void)
{
	return "malidrv: MALI_OS_MEMORY_KERNEL_BUFFER_SIZE_IN_MB=64" VERSION_STRINGS;
}
